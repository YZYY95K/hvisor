QEMU := qemu-system-riscv64


FSIMG1 := $(image_dir)/virtdisk/rootfs1.ext4
FSIMG2 := $(image_dir)/virtdisk/rootfs2.ext4
# HVISOR ENTRY
HVISOR_ENTRY_PA := 0x80200000
zone0_kernel := $(image_dir)/kernel/Image
zone0_dtb    := $(image_dir)/dts/zone0.dtb
# zone1 (Asterinas) images
# kernel and dtb are loaded by hvisor-tool from zone0 (see zone1-asterinas.json)
# initramfs is pre-loaded via QEMU loader since hvisor-tool RISC-V doesn't support it yet
zone1_kernel := $(image_dir)/kernel/asterinas.bin
zone1_dtb    := $(image_dir)/dts/zone1-asterinas.dtb
zone1_initramfs := $(image_dir)/kernel/initramfs.cpio.gz

QEMU_ARGS := -machine virt,aclint=on # ,iommu-sys=on # -d trace:*iommu*
QEMU_ARGS += -bios default
QEMU_ARGS += -cpu rv64
QEMU_ARGS += -smp 4
QEMU_ARGS += -m 4G
QEMU_ARGS += -nographic

QEMU_ARGS += -kernel $(hvisor_bin)
QEMU_ARGS += -device loader,file="$(zone0_kernel)",addr=0x90000000,force-raw=on
QEMU_ARGS += -device loader,file="$(zone0_dtb)",addr=0x8f000000,force-raw=on
# Pre-load zone1 (Asterinas) initramfs into memory (hvisor-tool RISC-V doesn't support initrd yet)
# zone1 kernel and dtb are loaded by hvisor-tool from zone0 (see zone1-asterinas.json)
QEMU_ARGS += -device loader,file="$(zone1_initramfs)",addr=0x87e00000,force-raw=on

QEMU_ARGS += -drive if=none,file=$(FSIMG1),id=hd0,format=raw
# QEMU_ARGS += -device virtio-blk-device,drive=hd0,bus=virtio-mmio-bus.7
QEMU_ARGS += -device virtio-blk-pci,drive=hd0,disable-legacy=on,disable-modern=off,addr=01.0 # ,iommu_platform=on
QEMU_ARGS += -device virtio-serial-device,bus=virtio-mmio-bus.6 -chardev pty,id=X10007000 -device virtconsole,chardev=X10007000 -S
QEMU_ARGS += -drive if=none,file=$(FSIMG2),id=hd1,format=raw
# QEMU_ARGS += -device virtio-blk-device,drive=hd1,bus=virtio-mmio-bus.5
QEMU_ARGS += -device virtio-blk-pci,drive=hd1,disable-legacy=on,disable-modern=off,addr=02.0 #,iommu_platform=on
# -------------------------------------------------------------------

# QEMU_ARGS := -machine virt
# QEMU_ARGS += -nographic 
# QEMU_ARGS += -cpu rv64 
# QEMU_ARGS += -m 3G 
# QEMU_ARGS += -smp 4 
# QEMU_ARGS += -bios default
# # QEMU_ARGS +=-bios $(BOOTLOADER)
# QEMU_ARGS += -kernel tenants/Image-62
# QEMU_ARGS += -drive file=imgs/rootfs-busybox.qcow2,format=qcow2,id=hd0 
# #QEMU_ARGS +=-drive file=../guests/rootfs-buildroot.qcow2,format=qcow2,id=hd0 
# QEMU_ARGS += -device virtio-blk-device,drive=hd0 
# QEMU_ARGS += -append "root=/dev/vda rw console=ttyS0"

# #QEMU_ARGS +=		 -device loader,file=$(KERNEL_BIN),addr=$(KERNEL_ENTRY_PA) 
# #QEMU_ARGS +=		 -device loader,file=../guests/os_ch5_802.bin,addr=0x80400000 			 
# #QEMU_ARGS +=		 -device virtio-serial-port -chardev pty,id=serial3 -device virtconsole,chardev=serial3
# QEMU_ARGS +=		 -device virtio-serial-device -chardev pty,id=serial3 -device virtconsole,chardev=serial3

$(hvisor_bin): elf
	$(OBJCOPY) $(hvisor_elf) --strip-all -O binary $@